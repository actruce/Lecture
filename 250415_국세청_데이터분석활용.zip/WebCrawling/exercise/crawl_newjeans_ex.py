# 셀레니움 웹 드라이버 임포트 해 주기
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Chrome 브라우저 열기
browser = webdriver.Chrome()

# 구글 페이지 연결시키기
url = "file:///F:/Downloads/NewJeans.html"

#go to board
try:
    browser.get(url)
  
except:
    print("ERROR while entering webpage")

print('\n\n')

# H1 Heading 정보 가져오기
# Hint :
# find_element, By.TAG_NAME
# element.text
#TO-DO

print('\n\n')

# 뉴진스 이미지의 경로 가져오기
# Hint :
# find_element, By.TAG_NAME
# element.get_attribute
#TO-DO

print('\n\n')

# 뉴진스 멤버정보 가져오기 (from unordered list)
# Hint :
# find_elements, By.TAG_NAME
# for-loop 안에서 element.text
#TO-DO

print('\n\n')

# 뉴진스 빌보드 핫 100 테이블 내용 가져오기
# find_element(By.ID)
# find_elements(By.TAG_NAME)
# for-loop 안에서 element.text
# TO-DO


time.sleep(10)    
browser.quit()