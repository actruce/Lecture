# 셀레니움 웹 드라이버 임포트 해 주기
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Chrome 브라우저 열기
browser = webdriver.Chrome()

# 구글 페이지 연결시키기
web_url = "http://web.stanford.edu/class/cs224n/"

#go to board
try:
    browser.get(web_url)
  
except:
    print("ERROR while entering webpage")
    

# cs224n 강의 홈페이지에서 'Schedule' 표 안의 내용에서 slides 라고 되어 있는 강의 노트의
# pdf 링크만 가져오자.
# Hint:
# find_element, By.ID, 'schedule'
# find_elements, By.TAG_NAME, 'a'
# 조건1 'slides' 가 해당 요소의 text 안에 있을 것
# 조건2 'pdf' 가 해당 요소의 'href' 속성 안에 있을 것
# 조건을 만족하는 href 속성의 값을 pdf_links 라는 list 변수안에 append 할 것!
# TO-DO

    
time.sleep(2)
browser.quit()

for pdf_link in pdf_links:
    print(pdf_link)


# To open pdf links and save the file (.pdf)
import wget

num_links = len(pdf_links)
idx = 1

print('DOWNLAOD THE PDF FILES IN {}'.format(web_url))

for file_link in pdf_links:
    #file_url = web_url + file_link
    file_url = file_link
    filepath = file_link.split('/')[1]
    
    print()
    print('[{}/{}] DOWNLOAD START: \'{}\''.format(idx, num_links, filepath))
    wget.download(file_url, filepath)
    
    idx += 1
    
print()
print()
print('DOWNLAOD completed !')